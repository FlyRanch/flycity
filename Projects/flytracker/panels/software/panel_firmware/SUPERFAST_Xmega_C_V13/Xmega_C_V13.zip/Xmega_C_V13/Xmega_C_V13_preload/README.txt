What are changes in version 1.1
1. Add readme.txt 
1. Add set_ao feature
2. start from the begining of the function upon 'start' command
3. add reset function x count and reset function y count